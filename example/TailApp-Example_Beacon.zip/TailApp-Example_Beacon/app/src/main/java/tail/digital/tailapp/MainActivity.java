package tail.digital.tailapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import digital.tail.sdk.tail_mobile_sdk.TailDMP;
import digital.tail.sdk.tail_mobile_sdk.TailDMPValues;
import digital.tail.sdk.tail_mobile_sdk.exception.TailDMPException;

public class MainActivity extends AppCompatActivity implements ActivityCompat.OnRequestPermissionsResultCallback{

    private EditText user_txtV;
    private int PERMISSION_REQUEST_ID = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //reference to txtEdit
        user_txtV = (EditText)findViewById(R.id.txt_email);

        //reference to Start button
        Button btStart = (Button)findViewById(R.id.startBt);
        btStart.setBackgroundColor(Color.parseColor("#4caf50"));
        btStart.setTextColor(Color.parseColor("#FFFFFF"));

        //reference to Stop button
        Button btStop = (Button)findViewById(R.id.stopBt);
        btStop.setBackgroundColor(Color.parseColor("#f44336"));
        btStop.setTextColor(Color.parseColor("#FFFFFF"));

        initApp();
    }

    private void initApp() {

        //ask permission to get geolocation data
        askpermission();

        //initializing TailDMP
        try {


            //Initialize the SDK
            TailDMP.initialize(getApplicationContext());

            // Set user as optin
            TailDMP.getInstance().setOptin(true);

            //enable sandbox mode
            TailDMP.getInstance().enableSandbox(true);

            //interval, in minutes, to collect data from deivce
            int intervalToCollectData = 15;

            //interval, in minutes, to senda data to server
            int intervalToSendData = 360; //6hs

            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                //Set interval that will config the collectDataJob and the sendDataJob (required)
                TailDMP.getInstance().setIntervalToExecuteJob(intervalToCollectData,intervalToSendData);
            }



        } catch (TailDMPException e) {
            e.printStackTrace();
        }
    }

    public void askpermission(){

        //check if the user allow us to use some private resources of this device
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {
            //We can add more than one  per requirement
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.RECEIVE_BOOT_COMPLETED},123);
        }
    }

    public void senddirect(View view){
        try {

            String urs_txt = user_txtV.getText().toString();

            //create a hash user
            TailDMP.getInstance().generateUserHashFromEmail(urs_txt);

            //send data without a automatic scheduled job service"
            //we are sending an empty tag
            TailDMP.getInstance().sendData("");

        }catch (TailDMPException e) {
            e.printStackTrace();
        }

    }

    public void startIt(View view){
        try {

            //Generate an userhash ID using an email provided by a text field
            TailDMP.getInstance().generateUserHashFromEmail(user_txtV.getText().toString());

            //get the instance of TailDMP SDK and start automatic job  or send data
            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                //we start beacon scan automatcally here
                //For Android 5.0 and greater  use this
                TailDMP.getInstance().startJob();

            }else{

                //For Android 4.x use this
                TailDMP.getInstance().sendData("");

            }

        }catch (TailDMPException e) {
            e.printStackTrace();
        }
    }

    public void stopIt(View view){

        //get the instance of TailDMP SDK and start automatic job  or send data
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                //we STOP beacon scan manually here
                TailDMP.getInstance().stopJob();
            } catch (TailDMPException e) {
                e.printStackTrace();
            }
        }


    }
    // BEACONS
    public void initBeacons(View view){

        //just initialize Beacon scan if we have location permission
        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            //init beacons tracking
            try {
                //we start beacon scan manually here
                TailDMP.getInstance().enableBeaconScan(this);
            } catch (TailDMPException e) {
                e.printStackTrace();
            }
        }else{
            //ask permission

            View v = findViewById(android.R.id.content);
            checkPermission(view);
        }

    }

    public void disableBeacons(View v){

        /*
        * If you want to disable beacon scan use this code
         */

        try {
            TailDMP.getInstance().disableBeaconScan();
        } catch (TailDMPException e) {
            e.printStackTrace();
        }



    }

    // =============================
    // ==>> ASK PERMISSION TO USER
    // =============================
    //http://stackoverflow.com/questions/38431587/error-client-must-have-access-coarse-location-or-access-fine-location
    //https://developer.android.com/training/permissions/requesting.html
    public void checkPermission(View view){
        //check if the user allow us to use some private resources of this device
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
                ){
            //Can add more as per requirement
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.READ_CONTACTS,Manifest.permission.RECEIVE_BOOT_COMPLETED},PERMISSION_REQUEST_ID);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if (requestCode == PERMISSION_REQUEST_ID) {

            int PERMISSION_GRANTED = -1;

            //loop through all permissions requested
            for(int i = 0; i<permissions.length; i++){

                //found ACCESS_COARSE_LOCATION
                if(permissions[i].equals("android.permission.ACCESS_COARSE_LOCATION")){
                    PERMISSION_GRANTED = grantResults[i];
                    break;
                }

            }

            // Check if the only required permission has been granted
            if (PERMISSION_GRANTED == PackageManager.PERMISSION_GRANTED) {
                // access to locations device granted
                //start beacon tracking here if you want to
                //initBeacons(null);

            } else {

                Snackbar.make(this.findViewById(android.R.id.content), "You must grant permission to access device location to use this feature!",
                        Snackbar.LENGTH_LONG).show();

            }

        }else{
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }


    }


}
