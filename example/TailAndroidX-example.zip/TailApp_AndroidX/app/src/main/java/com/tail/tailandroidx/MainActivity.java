package com.tail.tailandroidx;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import digital.tail.sdk.tail_mobile_sdk.TailDMP;
import digital.tail.sdk.tail_mobile_sdk.exception.TailDMPException;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //reference to Start button
        Button btStart = (Button)findViewById(R.id.bt_start);
        btStart.setBackgroundColor(Color.parseColor("#4caf50"));
        btStart.setTextColor(Color.parseColor("#FFFFFF"));

        //reference to Stop button
        Button btStop = (Button)findViewById(R.id.bt_stop);
        btStop.setBackgroundColor(Color.parseColor("#f44336"));
        btStop.setTextColor(Color.parseColor("#FFFFFF"));


        initApp();

    }

    private void initApp() {
        try {
            //Initialize the SDK
            TailDMP.initialize(getApplicationContext());

            // Set user as optin
            TailDMP.getInstance().setOptin(true);

            //Enable sandbox mode: true/false
            TailDMP.getInstance().enableSandbox(true);

            //interval, in minutes, to collect data from device
            int intervalToCollectData = 15;

            //interval, in minutes, to send data to server
            int intervalToSendData = 360; //6hs

            //Set interval that will fires up the collectDataJob and the sendDataJob (required)
            TailDMP.getInstance().setIntervalToExecuteJob(intervalToCollectData,intervalToSendData);


            askPermission();

        } catch (TailDMPException e) {
            e.printStackTrace();
        }

    }

    private  final int PERMISSION_REQUEST_ID = 123;
    private  final int PERMISSION_REQUEST_ID_BG = 456;



    public void sendDirect(View view){
        try {
            //send data without a automatic scheduled job service"
            //we are sending an empty tag
            TailDMP.getInstance().sendData("");

        }catch (TailDMPException e) {
            e.printStackTrace();
        }

    }

    public void clickStartServices(View v){
        try{
            //get the instance of TailDMP SDK and stop the job
            TailDMP.getInstance().startJob();

        }catch (Exception e){

        }
    }

    public void clickStopServices(View v){
        try{
            //get the instance of TailDMP SDK and stop the job
            TailDMP.getInstance().stopJob();
        }catch (Exception e){

        }
    }


    public void askPermission(){
        //We can add more than one  per requirement
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACTIVITY_RECOGNITION, Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION},PERMISSION_REQUEST_ID);
    }

    public void askPermissionBG(){
        //We can add more than one  per requirement
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_BACKGROUND_LOCATION},PERMISSION_REQUEST_ID_BG);
    }



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {


        if(requestCode == PERMISSION_REQUEST_ID || requestCode == PERMISSION_REQUEST_ID_BG) {
            boolean foregroundLocAccess = false;
            boolean backgroundLocAccess = false;
            for(int i = 0; i<permissions.length; i++){
                if(permissions[i].equals("android.permission.ACCESS_COARSE_LOCATION")){
                    foregroundLocAccess = true;
                }else if(permissions[i].equals("android.permission.ACCESS_BACKGROUND_LOCATION")){
                    backgroundLocAccess = true;
                }
            }

            if(foregroundLocAccess){
                //permission foreground location granted, so ask for background location
                if(!backgroundLocAccess){
                    askPermissionBG();
                }
            }else{
                //permission foreground location denied, handle this case and ask again later
            }

        }


    }
}