package tail.digital.tailapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


import digital.tail.sdk.tail_mobile_sdk.ITSendEvents;
import digital.tail.sdk.tail_mobile_sdk.TailDMP;

import digital.tail.sdk.tail_mobile_sdk.exception.TailDMPException;

public class MainActivity extends AppCompatActivity implements ITSendEvents {

    private EditText user_txtV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //reference to txtEdit
        user_txtV = (EditText)findViewById(R.id.txt_email);

        //reference to Start button
        Button btStart = (Button)findViewById(R.id.start_bt);
        btStart.setBackgroundColor(Color.parseColor("#4caf50"));
        btStart.setTextColor(Color.parseColor("#FFFFFF"));

        //reference to Stop button
        Button btStop = (Button)findViewById(R.id.stop_bt);
        btStop.setBackgroundColor(Color.parseColor("#f44336"));
        btStop.setTextColor(Color.parseColor("#FFFFFF"));

        initApp();
    }

    private void initApp() {

        //ask permission to get geolocation data
        askpermission();

        //initializing TailDMP
        try {

            //Initialize the SDK
            TailDMP.initialize(getApplicationContext());

            // Set user as optin
            TailDMP.getInstance().setOptin(true);

            //Enable sandbox mode: true/false
            TailDMP.getInstance().enableSandbox(true);

            //interval, in minutes, to collect data from device
            int intervalToCollectData = 15;

            //interval, in minutes, to send data to server
            int intervalToSendData = 360; //6hs

            //Set interval that will fires up the collectDataJob and the sendDataJob (required)
            TailDMP.getInstance().setIntervalToExecuteJob(intervalToCollectData,intervalToSendData);

            //generate user hash before send data, the
            //TailDMP.getInstance().generateUserHashFromEmail(urs_txt);

            //startjob at initializing
           // TailDMP.getInstance().startJob();



        } catch (TailDMPException e) {
            e.printStackTrace();
        }
    }

    public void askpermission(){

        //check if the user allow us to use some private resources of this device
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {
            //We can add more than one  per requirement
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.RECEIVE_BOOT_COMPLETED},123);
        }
    }

    public void addEvent(View view){

        // if you have some error of compilation like: "cannot resolve method on  TailDMP"
        // go to build gradle and add the latest version of sdk
        // ex: compile 'digital.tail.sdk.tail_mobile_sdk:tail-mobile-sdk:1.2.29'
        try{
            //adding event
            TailDMP.getInstance().addEvent("_viewProduct", "sku_1");
        }catch(Exception e){
            Log.e("ERROR", "Exception");
        }
    }

    public void sendEvents(View view){
        try{

            // if you have some error of compilation like: "cannot resolve method on TailDMP"
            // open build.gradle file and add the latest version of sdk available
            // ex: compile 'digital.tail.sdk.tail_mobile_sdk:tail-mobile-sdk:1.2.29'

    	   /*
            Sending all saved events to tailtarget server  and use callback to get response of send events operation.
            */
            boolean sendEventsOperation = TailDMP.getInstance().sendEvents(this);


            /*
              //Sending all saved events to tailtarget server without callback.
              boolean sendEventsOperation = TailDMP.getInstance().sendEvents(null);
            */


            if(sendEventsOperation){
                Log.i("OK", "Operation Initialized!");
            }else{
                Log.e("ERROR", "Operation NOT Initialized!");
                // do some task to handle this.
            }
        }catch (Exception e){
            Log.e("ERROR", "Exception");
        }
    }

    public void sendDirect(View view){
        try {

            String urs_txt = user_txtV.getText().toString();

            //create a hash user
            TailDMP.getInstance().generateUserHashFromEmail(urs_txt);

            //send data without a automatic scheduled job service"
            //we are sending an empty tag
            TailDMP.getInstance().sendData("");

        }catch (TailDMPException e) {
            e.printStackTrace();
        }

    }

    public void startIt(View view){
        try {

            //Generate an userhash ID using an email provided by a text field
            TailDMP.getInstance().generateUserHashFromEmail(user_txtV.getText().toString());


            //start scheduled job service to send data hourly
            TailDMP.getInstance().startJob();

        }catch (TailDMPException e) {
            e.printStackTrace();
        }
    }

    public void stopIt(View view){
        try {
            TailDMP.getInstance().stopJob();
        }catch (TailDMPException e) {
            e.printStackTrace();
        }
    }

    //Callback function
    // if
    @Override
    public void sendEventsResults(boolean b) {
        if(b){
            Log.i("CALLBACK", "Events sent!!");
        }else{
            Log.e("CALLBACK", "Ooops some error occurred while sending events!!");
        }

    }
}
